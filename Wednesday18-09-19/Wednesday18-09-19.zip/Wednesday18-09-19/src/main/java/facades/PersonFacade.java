package facades;

import dto.PersonDTO;
import dto.PersonDTOnoaddress;
import entities.Address;
import entities.Person;
import exceptions.MissingInputException;
import exceptions.PersonNotFoundException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 *
 * Rename Class to a relevant name Add add relevant facade methods
 */
public class PersonFacade implements IPersonFacade {

    private static PersonFacade instance;
    private static EntityManagerFactory emf;

    //Private Constructor to ensure Singleton
    private PersonFacade() {
    }

    /**
     *
     * @param _emf
     * @return an instance of this facade class.
     */
    public static PersonFacade getPersonFacade(EntityManagerFactory _emf) {
        if (instance == null) {
            emf = _emf;
            instance = new PersonFacade();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    //TODO Remove/Change this before use
    public long getPersonCount() {
        EntityManager em = emf.createEntityManager();
        try {
            long personCount = (long) em.createQuery("SELECT COUNT(r) FROM Person r").getSingleResult();
            return personCount;
        } finally {
            em.close();
        }
    }

    @Override
    public Person addPerson(String fName, String lName, String phone, Address address) throws MissingInputException {
        EntityManager em = getEntityManager();
        try {
            try {
                Date date = new Date();
                Person p = new Person(fName, lName, phone, date, date, address);
                if (p.getFirstName().isEmpty() || p.getLastName().isEmpty() || p.getPhone().isEmpty()) {
                    throw new MissingInputException("First Name and/or Last Name is missing");
                }
                em.getTransaction().begin();
                em.persist(address);
                em.persist(p);
                em.getTransaction().commit();
                return p;
            } finally {
                em.close();
            }
        } catch (Exception e) {
            throw new MissingInputException("First Name and/or Last Name is missing");
        }
    }

    @Override
    public Person deletePerson(int id) throws PersonNotFoundException {
        EntityManager em = getEntityManager();
        try {
            try {
                em.getTransaction().begin();
                Person pers = em.merge(getPerson(id));
                em.remove(pers);
                em.getTransaction().commit();
                return pers;
            } finally {
                em.close();
            }
        } catch (NullPointerException e) {
            throw new PersonNotFoundException("Could not delete, provided id does not exist");
        } catch (Exception e) {
            throw new PersonNotFoundException(e.getMessage());
        }
    }

    @Override
    public Person getPerson(int id) throws PersonNotFoundException {
        try {
            return getEntityManager().find(Person.class, id);
        } catch (NullPointerException e) {
            throw new PersonNotFoundException("No person with provided id found");
        }
    }

    public PersonDTO getPersonDTO(int id) throws PersonNotFoundException {
        try {
            return new PersonDTO(getPerson(id));
        } catch (NullPointerException e) {
            throw new PersonNotFoundException("No person with provided id found");
        }
    }

    @Override
    public List<Person> getAllPersons() {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<Person> query = em.createQuery("SELECT p FROM Person p", Person.class);
            List<Person> l = query.getResultList();
            return l;
        } finally {
            em.close();
        }
    }

    public List<Person> getAllPersonsDTO() {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<Person> query = em.createQuery("SELECT p FROM Person p", Person.class);
            List<Person> l = query.getResultList();
            return l;
        } finally {
            em.close();
        }
    }

    @Override
    public Person editPerson(Person p) throws PersonNotFoundException {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        Person pMerge = em.find(Person.class, p.getId());
        pMerge.setFirstName(p.getFirstName());
        pMerge.setLastName(p.getLastName());
        pMerge.setPhone(p.getPhone());
        pMerge.setLastEdited(new Date());
        pMerge.setAddress(p.getAddress());
        em.merge(pMerge);

        em.getTransaction().commit();
        em.close();
        return pMerge;
    }

    public void populate() throws MissingInputException {
        Date date = new Date();
        date.setTime(System.currentTimeMillis());
        
        addPerson("Sheriff", "of Nottingham", "911",new Address("vej1",2900,"by1"));
        addPerson("Sheriff", "of Nottingham", "911",new Address("vej2",3900,"by2"));
        addPerson("Sheriff", "of Nottingham", "911",new Address("vej3",4900,"by3"));
        addPerson("Sheriff", "of Nottingham", "911",new Address("vej4",9999,"by4"));
    }

    
    public List<PersonDTOnoaddress> getAllPersonsNoAddres() {
        PersonFacade pf = new PersonFacade();
        List<Person> l = pf.getAllPersons();
        List<PersonDTOnoaddress> lDTO = new ArrayList();
        for (int i = 0; i < l.size(); ++i) {
            lDTO.add(new PersonDTOnoaddress(l.get(i)));
        }
        return lDTO;
    }
    
}
