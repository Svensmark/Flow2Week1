package facade;

import entities.Address;
import entities.Person;
import exceptions.MissingInputException;
import exceptions.PersonNotFoundException;
import facades.PersonFacade;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import utils.EMF_Creator;

public class PersonFacadeTest {

    private static EntityManagerFactory emf;
    private static PersonFacade facade;

    public PersonFacadeTest() {
    }

    @BeforeAll
    public static void setUpClass() {
        emf = EMF_Creator.createEntityManagerFactory(
                "pu",
                "jdbc:mysql://localhost:3307/startcode_test",
                "dev",
                "ax2",
                EMF_Creator.Strategy.CREATE);
        facade = PersonFacade.getPersonFacade(emf);
    }

    /*   **** HINT **** 
        A better way to handle configuration values, compared to the UNUSED example above, is to store those values
        ONE COMMON place accessible from anywhere.
        The file config.properties and the corresponding helper class utils.Settings is added just to do that. 
        See below for how to use these files. This is our RECOMENDED strategy
     */
    @BeforeAll
    public static void setUpClassV2() {
        emf = EMF_Creator.createEntityManagerFactory(EMF_Creator.DbSelector.TEST, EMF_Creator.Strategy.DROP_AND_CREATE);
        facade = PersonFacade.getPersonFacade(emf);
    }
    
    @BeforeEach
    public void setUp() {
        Persistence.generateSchema("pu", null);
        EntityManager em = emf.createEntityManager();
        
        try {
            Date date = new Date();
            em.getTransaction().begin();
            em.createNamedQuery("Person.deleteAllRows").executeUpdate();
            em.getTransaction().commit();
            
            em.getTransaction().begin();
            Address a = new Address("vej1",200,"by1");
            em.persist(a);
            em.persist(new Person("Turqoise with a hint of yellowgreen", "Meep", "bittersweet",date,date,a));
            em.getTransaction().commit();
         
            em.getTransaction().begin();
            a = new Address("vej123",200,"byasdgag1");
            em.persist(a);
            em.persist(new Person("Turqasgiojshgijoagioj a hint of yellowgreen", "Msadaoifsiof", "bitterssssssweet",date,date,a));
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }
    
    

    @Test
    public void testAddPerson() throws MissingInputException{
        EntityManager em = emf.createEntityManager();

        TypedQuery<Person> query = em.createQuery("SELECT m FROM Person m", Person.class);
        List l = query.getResultList();
        int before = l.size();
        
        facade.addPerson("AddPerson", "Test", "wat",new Address("v1419",200,"BY NAVN1"));
        query = em.createQuery("SELECT m FROM Person m", Person.class);
        l = query.getResultList();
        int after = l.size();

        assertEquals(before + 1, after);
    }

    
    @Test
    public void testDeletePerson() throws PersonNotFoundException{
        EntityManager em = emf.createEntityManager();

        TypedQuery<Person> query = em.createQuery("SELECT m FROM Person m", Person.class);
        List l = query.getResultList();
        int before = l.size();
        
        Date date = new Date();
        Person person = new Person("DeletePerson", "Test", "a", date, date,new Address("vej105",200,"by150"));
        em.getTransaction().begin();
        em.persist(person);
        em.getTransaction().commit();
        facade.deletePerson(person.getId());

        l = query.getResultList();
        int after = l.size();

        assertEquals(before, after);
    }

    
    @Test
    public void testGetPerson() {
        EntityManager em = emf.createEntityManager();
        TypedQuery<Person> query = em.createQuery("SELECT m FROM Person m WHERE m.firstName = 'Turqoise with a hint of yellowgreen'", Person.class);
        Person p = query.getSingleResult();
        assertEquals("Turqoise with a hint of yellowgreen", p.getFirstName());
    }

    @Test
    public void testGetAllPerson() {
        EntityManager em = emf.createEntityManager();
        TypedQuery<Person> query = em.createQuery("SELECT m FROM Person m", Person.class);
        List l = query.getResultList();

        assertEquals(l.size(), facade.getAllPersons().size());
        assertEquals("Msadaoifsiof", facade.getAllPersons().get(1).getLastName());
    }

    @Test
    public void testEditPerson() {
        EntityManager em = emf.createEntityManager();
        TypedQuery<Person> query = em.createQuery("SELECT m FROM Person m WHERE m.firstName = 'Turqoise with a hint of yellowgreen'", Person.class);
        Person p1 = query.getSingleResult();
        int id = p1.getId();
        String expected = "Last name changed";
        Person p2 = em.find(Person.class, id);
        p2.setLastName(expected);
        em.merge(p2);
        
        Person res= query.getSingleResult();
        assertEquals(expected,res.getLastName());
    }
}
