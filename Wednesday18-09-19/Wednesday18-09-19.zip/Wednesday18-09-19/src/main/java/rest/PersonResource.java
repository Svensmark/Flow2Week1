package rest;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dto.PersonDTO;
import entities.Person;
import exceptions.MissingInputException;
import exceptions.PersonNotFoundException;
import utils.EMF_Creator;
import facades.PersonFacade;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.persistence.EntityManagerFactory;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

//Todo Remove or change relevant parts before ACTUAL use
@Path("person")
public class PersonResource {

    private static final EntityManagerFactory EMF = EMF_Creator.createEntityManagerFactory(
            "pu",
            "jdbc:mysql://localhost:3307/persondatabase",
            "dev",
            "ax2",
            EMF_Creator.Strategy.CREATE);
    private static final PersonFacade FACADE = PersonFacade.getPersonFacade(EMF);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public String demo() {
        return "{\"msg\":\"Hello World\"}";
    }

    @Path("/populate")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public String populate() throws MissingInputException{
        FACADE.populate();
        return "{\"msg\":\"Your database has been populated..\"}";
    }

    @Path("/id/{id}")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public String getPerson(Person entity, @PathParam("id") int id) throws PersonNotFoundException{
            return GSON.toJson(FACADE.getPersonDTO(id));
    }

    @Path("/all")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public String getAllPersons() {
        HashMap<String, List<Person>> hm = new HashMap();
        hm.put("all", FACADE.getAllPersonsDTO());
        return GSON.toJson(hm);
    }
    
    @Path("/all/list")
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public String getAllPersonslIST() {
        return GSON.toJson(FACADE.getAllPersonsNoAddres());
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addPerson(String person) throws MissingInputException{
        Person p = GSON.fromJson(person, Person.class);
        Person pper = FACADE.addPerson(p.getFirstName(), p.getLastName(), p.getPhone(),p.getAddress());
        return Response.ok(pper).build();
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response editPerson(String person) throws PersonNotFoundException{
            Person p = GSON.fromJson(person, Person.class);
            Person k = FACADE.getPerson(p.getId());
            k.setFirstName(p.getFirstName());
            k.setLastName(p.getLastName());
            k.setLastEdited(new Date());
            k.setPhone(p.getPhone());
            FACADE. editPerson(k);
            return Response.ok(k).build();
    }

    @DELETE
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response deletePerson(String person) throws PersonNotFoundException{
        Person p = GSON.fromJson(person, Person.class);
        FACADE.deletePerson(p.getId());
        return Response.ok(person).build();
    }

}
